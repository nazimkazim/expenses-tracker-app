[{
    "id": 1,
    "first_name": "Ezechiel",
    "last_name": "Carlo",
    "email": "ecarlo0@furl.net",
    "gender": "Male"
  }, {
    "id": 2,
    "first_name": "Freddie",
    "last_name": "Caulliere",
    "email": "fcaulliere1@usda.gov",
    "gender": "Male"
  }, {
    "id": 3,
    "first_name": "Giff",
    "last_name": "Kinsley",
    "email": "gkinsley2@kickstarter.com",
    "gender": "Male"
  }, {
    "id": 4,
    "first_name": "Gauthier",
    "last_name": "McMinn",
    "email": "gmcminn3@usgs.gov",
    "gender": "Male"
  }, {
    "id": 5,
    "first_name": "Rosalie",
    "last_name": "Trewhela",
    "email": "rtrewhela4@craigslist.org",
    "gender": "Female"
  }]
  